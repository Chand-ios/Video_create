### Danagul Otel
- IOS developer at VEON company, young and curious
- [![twitter-alt][twitter-img]](https://twitter.com/danchokaa)
  [![github-alt][github-img]](https://github.com/danchokobo)
  [![linkedin-alt][linkedin-img]](https://www.linkedin.com/in/danagul-otel-9b841a122/)